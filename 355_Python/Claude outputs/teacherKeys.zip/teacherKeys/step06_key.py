# ===== Problem 1: Print a list =====
foods = ["pizza", "tacos", "ramen", "wings"]
for food in foods:
    print(food)

# ===== Problem 2: First, last, and how many =====
states = ["Ohio", "Texas", "Maine", "Utah", "Iowa"]
print(f"First: {states[0]}")
print(f"Last:  {states[-1]}")
print(f"Count: {len(states)}")

# ===== Problem 3: Change an item =====
groceries = ["milk", "bread", "eggs"]
print(groceries)
groceries[1] = "bagels"
groceries.append("juice")
print(groceries)

# ===== Problem 4: Numbered menu =====
snacks = ["Chips", "Pretzels", "Popcorn", "Trail mix"]
print("--- Snack Menu ---")
for i in range(len(snacks)):
    print(f"{i + 1}. {snacks[i]}")

# ===== Problem 5: Team list from input =====
team = []
for count in range(3):
    name = input("Player name: ")
    team.append(name)
print("Team: " + ", ".join(team))

# ===== Problem 6: Total and average =====
prices = [4.99, 12.50, 3.25, 8.00]
total = 0
for price in prices:
    total = total + price
average = total / len(prices)
print(f"Total:   ${total:.2f}")
print(f"Average: ${average:.2f}")

# ===== Problem 7: Count the passing scores =====
scores = [88, 64, 92, 71, 55, 79, 100]
passing = 0
for score in scores:
    if score >= 70:
        passing = passing + 1
print(f"{passing} of {len(scores)} scores are passing.")

# ===== Problem 8: Highest temperature =====
temps = [61, 58, 67, 72, 64, 59, 70]
highest = temps[0]
for temp in temps:
    if temp > highest:
        highest = temp
print(f"Highest: {highest}")

# ===== Problem 9: Lowest and which day =====
temps = [61, 58, 67, 72, 64, 59, 70]
lowest_index = 0
for i in range(len(temps)):
    if temps[i] < temps[lowest_index]:
        lowest_index = i
print(f"Lowest: {temps[lowest_index]} on day {lowest_index + 1}")

# ===== Problem 10: Keep adding until done =====
items = []
item = input("Item (done to stop): ")
while item != "done":
    items.append(item)
    item = input("Item (done to stop): ")
print(f"You packed {len(items)} items:")
for item in items:
    print(f"- {item}")

# ===== Problem 11: Sort both ways =====
times = [48, 52, 45, 50, 47]
print(f"Fastest first: {sorted(times)}")
print(f"Slowest first: {sorted(times, reverse=True)}")
print(f"Original:      {times}")

# ===== Problem 12: Average with a function =====
def average(numbers):
    """Purpose: average a list of numbers.
    Parameters: numbers (list of int)
    Returns: the average (float)
    """
    total = 0
    for number in numbers:
        total = total + number
    return total / len(numbers)

print(f"Quiz average: {average([8, 10, 7, 9]):.1f}")
print(f"Test average: {average([88, 92, 75]):.1f}")

# ===== Challenge: Daily Steps Tracker =====
GOAL = 10000

def main():
    """Purpose: run the program. Parameters: none. Returns: nothing"""
    days = int(input("How many days? (1-7): "))
    while days < 1 or days > 7:
        print("Please enter 1 to 7.")
        days = int(input("How many days? (1-7): "))

    steps = []
    for day in range(1, days + 1):
        count = int(input(f"Steps on day {day}: "))
        steps.append(count)

    total = 0
    goal_days = 0
    best_index = 0
    for i in range(len(steps)):
        total = total + steps[i]
        if steps[i] >= GOAL:
            goal_days = goal_days + 1
        if steps[i] > steps[best_index]:
            best_index = i

    print()
    print("--- Step Report ---")
    print(f"Total steps:   {total}")
    print(f"Average:       {total / len(steps):.1f}")
    print(f"Best day:      day {best_index + 1} ({steps[best_index]} steps)")
    print(f"Goal reached:  {goal_days} of {len(steps)} days")
    print(f"Sorted:        {sorted(steps)}")

if __name__ == "__main__":
    main()


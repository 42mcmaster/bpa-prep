# ===== Problem 1: Three lines =====
print("Welcome to Software Engineering!")
print("Room 112, IT Academy")
print("Medina County Career Center")

# ===== Problem 2: Blank lines =====
print("BPA Meeting")
print()
print("Tuesday after school")
print("Bring your laptop")
print()
print("See you there!")

# ===== Problem 3: A border =====
print("=" * 30)
print("BPA PYTHON CLUB")
print("=" * 30)

# ===== Problem 4: Centered title =====
print("=" * 30)
print("       BPA PYTHON CLUB")
print("=" * 30)

# ===== Problem 5: A lined-up card =====
print("-" * 24)
print("Name:      Jordan Lee")
print("Grade:     11")
print("Program:   Software Eng")
print("-" * 24)

# ===== Problem 6: Quotes inside text =====
print("The coach said \"Push your code every day.\"")
print("It's the best way to save your work.")

# ===== Problem 7: A file path =====
print("Save your work in:")
print("C:\\BPA\\Python\\step01")

# ===== Problem 8: One print, three lines =====
print("Line 1: Python\nLine 2: GitHub\nLine 3: BPA")

# ===== Problem 9: A box =====
print("*" * 12)
print("*" + " " * 10 + "*")
print("*" + " " * 10 + "*")
print("*" * 12)

# ===== Problem 10: Header and comments =====
# Name: Your Name
# Date: 2026-11-16
# Program: Step 1 Practice 10
# Description: Prints today's lunch menu.

# Output: the menu title and items
print("TODAY'S LUNCH")
print("-" * 13)
print("1. Chicken wrap")
print("2. Garden salad")
print("3. Pizza")

# ===== Problem 11: Fix the errors =====
print("Game Night")
print("Friday at 6:00 PM")
print("Room 112")

# ===== Challenge: Club Flyer =====
# Name: Your Name
# Date: 2026-11-16
# Program: Step 1 Challenge - Club Flyer
# Description: Prints a flyer for the Python Club.

# Output: the flyer
print("=" * 32)
print("        PYTHON CLUB")
print("    Every Tuesday at 2:45")
print("=" * 32)
print()
print("Where:    Room 112")
print("Bring:    Your laptop")
print("Who:      Juniors and seniors")
print()
print("Motto: \"Code it, test it, push it.\"")
print("Files: C:\\BPA\\club")
print("-" * 32)


# ===== Problem 1: A simple menu =====
choice = 0
while choice != 3:
    print("1. Say hello  2. Say goodbye  3. Quit")
    choice = int(input("Choose: "))
    if choice == 1:
        print("Hello!")
    elif choice == 2:
        print("Goodbye!")
print("Program ended.")

# ===== Problem 2: A counter menu =====
count = 0
choice = 0
while choice != 3:
    print("1. Add one  2. Show count  3. Quit")
    choice = int(input("Choose: "))
    if choice == 1:
        count = count + 1
    elif choice == 2:
        print(f"Count: {count}")
print(f"Final count: {count}")

# ===== Problem 3: A crash-proof menu =====
def get_int(prompt, low, high):
    """Purpose: ask until the answer is a whole number from low to high.
    Parameters: prompt (str), low (int), high (int)
    Returns: the number (int)
    """
    while True:
        try:
            number = int(input(prompt))
            if number >= low and number <= high:
                return number
        except ValueError:    # catches letters and decimals
            pass
        print(f"Please enter a whole number from {low} to {high}.")

choice = 0
while choice != 3:
    print("1. Say hello  2. Say goodbye  3. Quit")
    choice = get_int("Choose: ", 1, 3)
    if choice == 1:
        print("Hello!")
    elif choice == 2:
        print("Goodbye!")
print("Program ended.")

# ===== Problem 4: One function per option =====
def show_meeting():
    """Purpose: print the meeting time. Parameters: none. Returns: nothing"""
    print("Meetings are Tuesdays at 2:45.")

def show_advisor():
    """Purpose: print the advisor. Parameters: none. Returns: nothing"""
    print("The advisor is Mr. McMaster.")

def main():
    """Purpose: run the menu. Parameters: none. Returns: nothing"""
    choice = 0
    while choice != 3:
        print("1. Meeting time  2. Club advisor  3. Quit")
        choice = int(input("Choose: "))
        if choice == 1:
            show_meeting()
        elif choice == 2:
            show_advisor()
    print("Bye!")

if __name__ == "__main__":
    main()

# ===== Problem 5: A Pet class =====
class Pet:
    """A pet with a name and a species."""
    def __init__(self, name, species):
        """Purpose: set up a Pet. Parameters: name (str), species (str). Returns: nothing"""
        self.name = name
        self.species = species

first = Pet("Biscuit", "dog")
second = Pet("Smokey", "cat")
print(f"{first.name} is a {first.species}.")
print(f"{second.name} is a {second.species}.")

# ===== Problem 6: A method that changes the object =====
class PiggyBank:
    """A piggy bank that holds money."""
    def __init__(self):
        """Purpose: start an empty bank. Parameters: none. Returns: nothing"""
        self.balance = 0.0

    def deposit(self, amount):
        """Purpose: add money. Parameters: amount (float). Returns: nothing"""
        self.balance = self.balance + amount

bank = PiggyBank()
bank.deposit(5.00)
bank.deposit(2.50)
bank.deposit(10.25)
print(f"Balance: ${bank.balance:.2f}")

# ===== Problem 7: A method that returns a value =====
class Rectangle:
    """A rectangle with a width and a height."""
    def __init__(self, width, height):
        """Purpose: set up a Rectangle. Parameters: width, height (float). Returns: nothing"""
        self.width = width
        self.height = height

    def area(self):
        """Purpose: work out the area. Parameters: none. Returns: the area (float)"""
        return self.width * self.height

width = float(input("Width: "))
height = float(input("Height: "))
room = Rectangle(width, height)
print(f"Area: {room.area():.1f}")

# ===== Problem 8: Print an object nicely =====
class Book:
    """A book with a title and an author."""
    def __init__(self, title, author):
        """Purpose: set up a Book. Parameters: title (str), author (str). Returns: nothing"""
        self.title = title
        self.author = author

    def __str__(self):
        """Purpose: text for print(). Parameters: none. Returns: the book as text (str)"""
        return f"{self.title} by {self.author}"

print(Book("Hatchet", "Gary Paulsen"))
print(Book("Holes", "Louis Sachar"))

# ===== Problem 9: A list of objects =====
class Student:
    """A student with a name and a grade."""
    def __init__(self, name, grade):
        """Purpose: set up a Student. Parameters: name (str), grade (int). Returns: nothing"""
        self.name = name
        self.grade = grade

roster = [Student("Avery", 92), Student("Blake", 78), Student("Casey", 85)]
total = 0
for student in roster:
    print(f"{student.name:<8}{student.grade:>4}")
    total = total + student.grade
print(f"Average: {total / len(roster):.1f}")

# ===== Problem 10: Find an object =====
class Student:
    """A student with a name and a grade."""
    def __init__(self, name, grade):
        """Purpose: set up a Student. Parameters: name (str), grade (int). Returns: nothing"""
        self.name = name
        self.grade = grade

roster = [Student("Avery", 92), Student("Blake", 78), Student("Casey", 85)]
search = input("Find student: ").strip().lower()
found = False
for student in roster:
    if student.name.lower() == search:
        print(f"{student.name}'s grade: {student.grade}")
        found = True
if not found:
    print("No student by that name.")

# ===== Problem 11: Best in the list =====
class Student:
    """A student with a name and a grade."""
    def __init__(self, name, grade):
        """Purpose: set up a Student. Parameters: name (str), grade (int). Returns: nothing"""
        self.name = name
        self.grade = grade

roster = [Student("Avery", 92), Student("Blake", 78), Student("Casey", 85)]
best = roster[0]
for student in roster:
    if student.grade > best.grade:
        best = student
print(f"Top student: {best.name} ({best.grade})")

# ===== Challenge: Snack Stand Manager =====
def get_int(prompt, low, high):
    """Purpose: ask until the answer is a whole number from low to high.
    Parameters: prompt (str), low (int), high (int)
    Returns: the number (int)
    """
    while True:
        try:
            number = int(input(prompt))
            if number >= low and number <= high:
                return number
        except ValueError:    # catches letters and decimals
            pass
        print(f"Please enter a whole number from {low} to {high}.")

class Snack:
    """A snack with a name, a price, and how many are left."""
    def __init__(self, name, price, stock):
        """Purpose: set up a Snack. Parameters: name (str), price (float), stock (int). Returns: nothing"""
        self.name = name
        self.price = price
        self.stock = stock

    def sell(self, amount):
        """Purpose: sell some if there are enough.
        Parameters: amount (int) - how many to sell
        Returns: True if sold, False if not enough (bool)
        """
        if amount > self.stock:
            return False
        self.stock = self.stock - amount
        return True

def show_snacks(snacks):
    """Purpose: print every snack. Parameters: snacks (list of Snack). Returns: nothing"""
    for i in range(len(snacks)):
        s = snacks[i]
        print(f"{i + 1}. {s.name:<10}${s.price:.2f}  ({s.stock} left)")

def sell_snack(snacks):
    """Purpose: sell some of one snack. Parameters: snacks (list of Snack). Returns: nothing"""
    show_snacks(snacks)
    pick = get_int(f"Which snack? (1-{len(snacks)}): ", 1, len(snacks))
    snack = snacks[pick - 1]
    amount = get_int("How many? (1-20): ", 1, 20)
    if snack.sell(amount):
        print(f"Sold {amount} {snack.name} for ${amount * snack.price:.2f}")
    else:
        print(f"Only {snack.stock} {snack.name} left.")

def main():
    """Purpose: run the menu. Parameters: none. Returns: nothing"""
    snacks = [Snack("Chips", 1.50, 10), Snack("Pretzels", 1.25, 4), Snack("Cookies", 2.00, 8)]
    choice = 0
    while choice != 3:
        print()
        print("--- SNACK STAND ---")
        print("1. Show snacks")
        print("2. Sell a snack")
        print("3. Quit")
        choice = get_int("Choose (1-3): ", 1, 3)
        if choice == 1:
            show_snacks(snacks)
        elif choice == 2:
            sell_snack(snacks)
    print("Stand closed.")

if __name__ == "__main__":
    main()


# ===== Problem 1: A welcome banner =====
def print_banner():
    """Purpose: print the welcome banner. Parameters: none. Returns: nothing"""
    print("=" * 20)
    print("  BPA Python Club")
    print("=" * 20)

print_banner()
print_banner()

# ===== Problem 2: Greet three people =====
def greet(name):
    """Purpose: print a greeting. Parameters: name (str). Returns: nothing"""
    print(f"Hello, {name}! Welcome to class.")

greet("Avery")
greet("Blake")
greet("Casey")

# ===== Problem 3: Square numbers =====
def square(number):
    """Purpose: square a number. Parameters: number (int). Returns: number times itself (int)"""
    return number * number

for n in range(1, 6):
    print(f"{n} squared is {square(n)}")

# ===== Problem 4: Average of three =====
def average_of_three(a, b, c):
    """Purpose: average three numbers.
    Parameters: a, b, c (int) - the three numbers
    Returns: the average (float)
    """
    return (a + b + c) / 3

first = int(input("Score 1: "))
second = int(input("Score 2: "))
third = int(input("Score 3: "))
print(f"Average: {average_of_three(first, second, third):.1f}")

# ===== Problem 5: Even or odd =====
def is_even(number):
    """Purpose: check if a number is even.
    Parameters: number (int)
    Returns: True if even, False if odd (bool)
    """
    return number % 2 == 0

number = int(input("Enter a number: "))
if is_even(number):
    print(f"{number} is even.")
else:
    print(f"{number} is odd.")

# ===== Problem 6: Letter grade =====
def letter_grade(score):
    """Purpose: turn a score into a letter grade.
    Parameters: score (int) - 0 to 100
    Returns: the letter (str)
    """
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"

score = int(input("Score: "))
print(f"Letter grade: {letter_grade(score)}")

# ===== Problem 7: Tip calculator =====
def calculate_tip(bill, percent):
    """Purpose: work out a tip.
    Parameters: bill (float) - the bill amount
                percent (int) - the tip percent, like 20
    Returns: the tip amount (float)
    """
    return bill * percent / 100

bill = float(input("Bill amount: "))
percent = int(input("Tip percent: "))
tip = calculate_tip(bill, percent)
print(f"Tip:   ${tip:.2f}")
print(f"Total: ${bill + tip:.2f}")

# ===== Problem 8: A line of any length =====
def print_line(symbol, length):
    """Purpose: print a line of one symbol.
    Parameters: symbol (str) - the character to repeat
                length (int) - how many times
    Returns: nothing
    """
    line = ""
    for count in range(length):
        line = line + symbol
    print(line)

print_line("*", 10)
print_line("-", 15)
print_line("#", 5)

# ===== Problem 9: Rectangle area and perimeter =====
def calculate_area(width, height):
    """Purpose: area of a rectangle. Parameters: width, height (float). Returns: the area (float)"""
    return width * height

def calculate_perimeter(width, height):
    """Purpose: perimeter of a rectangle. Parameters: width, height (float). Returns: the perimeter (float)"""
    return 2 * width + 2 * height

width = float(input("Width: "))
height = float(input("Height: "))
print(f"Area:      {calculate_area(width, height):.1f}")
print(f"Perimeter: {calculate_perimeter(width, height):.1f}")

# ===== Problem 10: Temperature table =====
def to_fahrenheit(celsius):
    """Purpose: convert Celsius to Fahrenheit.
    Parameters: celsius (float)
    Returns: the Fahrenheit temperature (float)
    """
    return celsius * 9 / 5 + 32

print("Celsius  Fahrenheit")
for celsius in range(0, 101, 20):
    print(f"{celsius:<9}{to_fahrenheit(celsius):.1f}")

# ===== Problem 11: Bigger of two =====
def bigger(a, b):
    """Purpose: find the bigger of two numbers.
    Parameters: a, b (int)
    Returns: the bigger number (int)
    """
    if a > b:
        return a
    else:
        return b

first = int(input("First number: "))
second = int(input("Second number: "))
print(f"The bigger number is {bigger(first, second)}")

# ===== Problem 12: Use main() =====
def calculate_total(price, quantity):
    """Purpose: cost of an order.
    Parameters: price (float) - price of one item
                quantity (int) - how many
    Returns: the total (float)
    """
    return price * quantity

def main():
    """Purpose: run the program. Parameters: none. Returns: nothing"""
    item = input("Item: ")
    price = float(input("Price: "))
    quantity = int(input("Quantity: "))
    total = calculate_total(price, quantity)
    print(f"{quantity} {item} cost ${total:.2f}")

if __name__ == "__main__":
    main()

# ===== Challenge: Pizza Order =====
PIZZA_PRICE = 11.99
TAX_RATE = 0.0675

def get_pizza_count():
    """Purpose: ask how many pizzas until the answer is 1 to 10.
    Parameters: none
    Returns: the number of pizzas (int)
    """
    count = int(input("How many pizzas? (1-10): "))
    while count < 1 or count > 10:
        print("Please enter 1 to 10.")
        count = int(input("How many pizzas? (1-10): "))
    return count

def calculate_subtotal(pizzas):
    """Purpose: cost before tax. Parameters: pizzas (int). Returns: the subtotal (float)"""
    return pizzas * PIZZA_PRICE

def calculate_tax(subtotal):
    """Purpose: sales tax. Parameters: subtotal (float). Returns: the tax (float)"""
    return subtotal * TAX_RATE

def print_receipt(name, pizzas, subtotal, tax):
    """Purpose: print the receipt.
    Parameters: name (str), pizzas (int), subtotal (float), tax (float)
    Returns: nothing
    """
    print()
    print(f"--- Order for {name} ---")
    print(f"Pizzas:    {pizzas}")
    print(f"Subtotal:  ${subtotal:.2f}")
    print(f"Tax:       ${tax:.2f}")
    print(f"Total:     ${subtotal + tax:.2f}")

def main():
    """Purpose: run the program. Parameters: none. Returns: nothing"""
    name = input("Name for the order: ")
    pizzas = get_pizza_count()
    subtotal = calculate_subtotal(pizzas)
    tax = calculate_tax(subtotal)
    print_receipt(name, pizzas, subtotal, tax)

if __name__ == "__main__":
    main()


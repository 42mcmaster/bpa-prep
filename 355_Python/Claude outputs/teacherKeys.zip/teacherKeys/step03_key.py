# ===== Problem 1: Pass or not =====
score = int(input("Score: "))
if score >= 70:
    print("You passed.")
else:
    print("You did not pass.")

# ===== Problem 2: Even or odd =====
number = int(input("Enter a number: "))
if number % 2 == 0:
    print(f"{number} is even.")
else:
    print(f"{number} is odd.")

# ===== Problem 3: Positive, negative, or zero =====
number = int(input("Enter a number: "))
if number > 0:
    print("Positive")
elif number < 0:
    print("Negative")
else:
    print("Zero")

# ===== Problem 4: Letter grade =====
score = int(input("Score: "))
if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
elif score >= 70:
    grade = "C"
elif score >= 60:
    grade = "D"
else:
    grade = "F"
print(f"Grade: {grade}")

# ===== Problem 5: Can they drive? =====
age = int(input("Age: "))
permit = input("Have a permit? (y/n): ")
if age >= 15 and permit.lower() == "y":
    print("You can drive with an adult.")
else:
    print("Not yet.")

# ===== Problem 6: Check the range first =====
rating = int(input("Rating (1-5): "))
if rating < 1 or rating > 5:
    print("Error: rating must be 1 to 5.")
else:
    print(f"Thanks for the rating of {rating}!")

# ===== Problem 7: Secret word =====
SECRET = "python"

guess = input("Guess the word: ")
if guess.lower() == SECRET:
    print("Correct!")
else:
    print("Wrong guess.")

# ===== Problem 8: Bigger number =====
first = int(input("First number: "))
second = int(input("Second number: "))
if first > second:
    print(f"{first} is bigger.")
elif second > first:
    print(f"{second} is bigger.")
else:
    print("They are equal.")

# ===== Problem 9: Free shipping and gift wrap =====
SHIPPING = 5.99
GIFT_WRAP = 3.00
FREE_SHIPPING_AT = 50.00

order = float(input("Order total: "))
wrap = input("Gift wrap? (y/n): ")
total = order
if order < FREE_SHIPPING_AT:
    total = total + SHIPPING
if wrap.lower() == "y":
    total = total + GIFT_WRAP
print(f"Final total: ${total:.2f}")

# ===== Problem 10: Member price =====
member = input("Club member? (y/n): ")
if member.lower() == "y":
    grade = int(input("Grade: "))
    if grade == 12:
        price = 3
    else:
        price = 5
else:
    price = 8
print(f"Your price: ${price}")

# ===== Problem 11: Late fee =====
DAILY_FEE = 0.25
MAX_FEE = 5.00

days = int(input("Days late: "))
fee = days * DAILY_FEE
if fee > MAX_FEE:
    fee = MAX_FEE
print(f"Late fee: ${fee:.2f}")

# ===== Challenge: Gym Day Pass =====
# Constants
CHILD_PRICE = 4.00
STUDENT_PRICE = 6.00
ADULT_PRICE = 9.00
WEEKEND_CHARGE = 2.00
TOWEL_PRICE = 1.50

# Input
name = input("Name: ")
age = int(input("Age: "))
day = input("Day of the week: ")
towel = input("Rent a towel? (y/n): ")

if age < 5 or age > 100:
    print("Error: age must be 5 to 100.")
else:
    # Processing: pick the pass type
    if age < 13:
        pass_type = "Child"
        price = CHILD_PRICE
    elif age <= 18:
        pass_type = "Student"
        price = STUDENT_PRICE
    else:
        pass_type = "Adult"
        price = ADULT_PRICE

    # Processing: extras (both can apply)
    total = price
    weekend = day.lower() == "saturday" or day.lower() == "sunday"
    if weekend:
        total = total + WEEKEND_CHARGE
    if towel.lower() == "y":
        total = total + TOWEL_PRICE

    # Output
    print()
    print(f"--- Day Pass for {name} ---")
    print(f"Pass type:  {pass_type}")
    print(f"Base price: ${price:.2f}")
    if weekend:
        print(f"Weekend:    ${WEEKEND_CHARGE:.2f}")
    if towel.lower() == "y":
        print(f"Towel:      ${TOWEL_PRICE:.2f}")
    print(f"Total:      ${total:.2f}")


# ===== Problem 1: One seat =====
seats = [["A1", "A2", "A3"],
         ["B1", "B2", "B3"],
         ["C1", "C2", "C3"]]
print(f"Middle seat: {seats[1][1]}")
print(f"End of row A: {seats[0][2]}")
print(f"Row C: {seats[2]}")

# ===== Problem 2: Print the chart =====
seats = [["A1", "A2", "A3"],
         ["B1", "B2", "B3"],
         ["C1", "C2", "C3"]]
for row in seats:
    line = ""
    for seat in row:
        line = line + seat + " "
    print(line.strip())

# ===== Problem 3: Row totals =====
minutes = [[30, 45, 20],
           [60, 10, 35],
           [25, 25, 30]]
week = 1
for row in minutes:
    total = 0
    for value in row:
        total = total + value
    print(f"Week {week}: {total} minutes")
    week = week + 1

# ===== Problem 4: Column totals =====
minutes = [[30, 45, 20],
           [60, 10, 35],
           [25, 25, 30]]
for col in range(3):
    total = 0
    for row in range(3):
        total = total + minutes[row][col]
    print(f"Day {col + 1}: {total} minutes")

# ===== Problem 5: Names and ages =====
names = ["Avery", "Blake", "Casey", "Devon"]
ages = [16, 17, 15, 18]
for i in range(len(names)):
    print(f"{names[i]} is {ages[i]}")

# ===== Problem 6: The oldest =====
names = ["Avery", "Blake", "Casey", "Devon"]
ages = [16, 17, 15, 18]
oldest = 0
for i in range(len(ages)):
    if ages[i] > ages[oldest]:
        oldest = i
print(f"Oldest: {names[oldest]} ({ages[oldest]})")

# ===== Problem 7: Scores from input =====
names = []
scores = []
for player in range(2):
    name = input("Name: ")
    row = []
    for round_number in range(1, 4):
        row.append(int(input(f"  Round {round_number}: ")))
    names.append(name)
    scores.append(row)
print(names)
print(scores)

# ===== Problem 8: Times table grid =====
for row in range(1, 6):
    line = ""
    for col in range(1, 6):
        line = line + f"{row * col:>4}"
    print(line)

# ===== Problem 9: A lined-up table =====
items = ["Pencils", "Notebooks", "Glue sticks"]
prices = [0.25, 1.99, 0.89]
print(f"{'Item':<14}{'Price':>7}")
print("-" * 21)
for i in range(len(items)):
    print(f"{items[i]:<14}{prices[i]:>7.2f}")

# ===== Problem 10: Menu lookup =====
menu = {"burger": 6.50, "fries": 2.75, "shake": 4.00}
item = input("What would you like? ").strip().lower()
if item in menu:
    print(f"A {item} is ${menu[item]:.2f}")
else:
    print("Not on the menu.")

# ===== Problem 11: Count the votes =====
votes = ["pizza", "tacos", "pizza", "wings", "tacos", "pizza"]
counts = {}
for vote in votes:
    if vote in counts:
        counts[vote] = counts[vote] + 1
    else:
        counts[vote] = 1
for food in counts:
    print(f"{food}: {counts[food]}")

# ===== Problem 12: Total of a table with a function =====
def table_total(table):
    """Purpose: add up every value in a list of lists.
    Parameters: table (list of lists of int)
    Returns: the total (int)
    """
    total = 0
    for row in table:
        for value in row:
            total = total + value
    return total

print(table_total([[1, 2], [3, 4]]))
print(table_total([[10, 20, 30], [5, 5, 5], [1, 1, 1]]))

# ===== Challenge: Gradebook Table =====
STUDENTS = 3
TESTS = 3

def get_score(prompt):
    """Purpose: ask for a score until it is 0 to 100.
    Parameters: prompt (str) - the question to ask
    Returns: the score (int)
    """
    score = int(input(prompt))
    while score < 0 or score > 100:
        print("Scores must be 0 to 100.")
        score = int(input(prompt))
    return score

def row_average(row):
    """Purpose: average one student's scores. Parameters: row (list of int). Returns: the average (float)"""
    total = 0
    for score in row:
        total = total + score
    return total / len(row)

def main():
    """Purpose: run the program. Parameters: none. Returns: nothing"""
    names = []
    scores = []
    for s in range(STUDENTS):
        names.append(input("Student name: "))
        row = []
        for t in range(1, TESTS + 1):
            row.append(get_score(f"  Test {t}: "))
        scores.append(row)

    print()
    print(f"{'Name':<10}{'T1':>5}{'T2':>5}{'T3':>5}{'Avg':>7}")
    print("-" * 32)
    best = 0
    for i in range(len(names)):
        avg = row_average(scores[i])
        print(f"{names[i]:<10}{scores[i][0]:>5}{scores[i][1]:>5}{scores[i][2]:>5}{avg:>7.1f}")
        if avg > row_average(scores[best]):
            best = i
    print("-" * 32)
    print(f"Top student: {names[best]}")

if __name__ == "__main__":
    main()


# ===== Problem 1: First and last letter =====
word = input("Enter a word: ")
print(f"First letter: {word[0]}")
print(f"Last letter:  {word[-1]}")
print(f"Length:       {len(word)}")

# ===== Problem 2: Shout and whisper =====
sentence = input("Say something: ")
print(sentence.upper())
print(sentence.lower())

# ===== Problem 3: Initials =====
first = input("First name: ")
last = input("Last name: ")
print(f"Initials: {first[0].upper()}.{last[0].upper()}.")

# ===== Problem 4: Username =====
first = input("First name: ")
last = input("Last name: ")
year = input("Graduation year: ")
username = (last[:4] + first[0] + year[-2:]).lower()
print(f"Username: {username}")

# ===== Problem 5: Count the vowels =====
sentence = input("Enter a sentence: ")
vowels = 0
for ch in sentence.lower():
    if ch in "aeiou":
        vowels = vowels + 1
print(f"Vowels: {vowels}")

# ===== Problem 6: Letters, digits, and spaces =====
text = input("Enter some text: ")
letters = 0
digits = 0
spaces = 0
for ch in text:
    if ch.isalpha():
        letters = letters + 1
    elif ch.isdigit():
        digits = digits + 1
    elif ch.isspace():
        spaces = spaces + 1
print(f"Letters: {letters}")
print(f"Digits:  {digits}")
print(f"Spaces:  {spaces}")

# ===== Problem 7: Hide the numbers =====
message = input("Message: ")
hidden = ""
for ch in message:
    if ch.isdigit():
        hidden = hidden + "*"
    else:
        hidden = hidden + ch
print(hidden)

# ===== Problem 8: Backwards =====
word = input("Enter a word: ").lower()
backwards = ""
for ch in word:
    backwards = ch + backwards
print(f"Backwards: {backwards}")
if word == backwards:
    print("It's a palindrome!")
else:
    print("Not a palindrome.")

# ===== Problem 9: Count the words =====
sentence = input("Enter a sentence: ")
words = sentence.split()
print(f"Words: {len(words)}")
print(f"First word: {words[0]}")
print(f"Last word:  {words[-1]}")

# ===== Problem 10: Yes or no =====
answer = input("Ready to start? (yes/no): ").strip().lower()
while answer != "yes" and answer != "no":
    print("Please type yes or no.")
    answer = input("Ready to start? (yes/no): ").strip().lower()
print(f"You said {answer}.")

# ===== Problem 11: Count a letter with a function =====
def count_letter(text, letter):
    """Purpose: count one letter in some text, ignoring capitals.
    Parameters: text (str) - the text to search
                letter (str) - the letter to count
    Returns: how many times it appears (int)
    """
    count = 0
    for ch in text.lower():
        if ch == letter.lower():
            count = count + 1
    return count

sentence = input("Sentence: ")
letter = input("Letter: ")
print(f"'{letter}' appears {count_letter(sentence, letter)} times.")

# ===== Challenge: Password Check =====
MIN_LENGTH = 8

def count_digits(text):
    """Purpose: count the digits. Parameters: text (str). Returns: the count (int)"""
    count = 0
    for ch in text:
        if ch.isdigit():
            count = count + 1
    return count

def count_uppercase(text):
    """Purpose: count the uppercase letters. Parameters: text (str). Returns: the count (int)"""
    count = 0
    for ch in text:
        if ch.isupper():
            count = count + 1
    return count

def is_strong(password):
    """Purpose: check all three rules and print what is missing.
    Parameters: password (str)
    Returns: True if every rule passes (bool)
    """
    strong = True
    if len(password) < MIN_LENGTH:
        print(f"- Needs at least {MIN_LENGTH} characters")
        strong = False
    if count_digits(password) == 0:
        print("- Needs at least 1 digit")
        strong = False
    if count_uppercase(password) == 0:
        print("- Needs at least 1 uppercase letter")
        strong = False
    return strong

def main():
    """Purpose: run the program. Parameters: none. Returns: nothing"""
    password = input("New password: ")
    while not is_strong(password):
        password = input("New password: ")
    print(f"Password accepted. It has {len(password)} characters.")

if __name__ == "__main__":
    main()


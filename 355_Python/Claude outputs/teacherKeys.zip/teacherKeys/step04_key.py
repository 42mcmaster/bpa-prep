# ===== Problem 1 =====
for number in range(1, 11):
    print(number)

# ===== Problem 2 =====
number = 1
while number <= 10:
    print(number)
    number = number + 1

# ===== Problem 3 =====
for number in range(2, 21, 2):
    print(number)

# ===== Problem 4 =====
total = 0
for number in range(1, 101):
    total = total + number
print(f'The total is {total}')

# ===== Problem 5 =====
PASSWORD = "python123"
entry = input("Enter the password: ")
while entry != PASSWORD:
    print("Try again!")
    entry = input("Enter the password: ")
print("Access granted!")

# ===== Problem 6 =====
number = int(input("Enter a number: "))
for i in range(1, 11):
    print(f"{number} x {i} = {number * i}")

# ===== Problem 7 =====
total = 0
number = int(input("Enter a number (0 to stop): "))
while number != 0:
    total = total + number
    number = int(input("Enter a number (0 to stop): "))
print(f"The total is {total}")

# ===== Problem 8 =====
start = int(input("Count down from: "))
for number in range(start, 0, -1):
    print(number)
print("Liftoff!")

# ===== Problem 9 =====
number = int(input("Enter a number (0 to stop): "))
while number != 0:
    if number < 0:
        print("Negative")
    else:
        print("Positive")
    number = int(input("Enter a number (0 to stop): "))
print("All done.")

# ===== Problem 10 =====
total = 0
for count in range(5):
    score = int(input("Test score: "))
    total = total + score
average = total / 5
print(f"Average: {average:.1f}")

# ===== Problem 11 =====
rating = int(input("Rate the movie (1-10): "))
while rating < 1 or rating > 10:
    print("Please enter 1 to 10.")
    rating = int(input("Rate the movie (1-10): "))
print(f"Your rating: {rating}")

# ===== Problem 12 =====
name = input("Player name: ")
points = int(input("Points scored: "))
bar = ""
for count in range(points):
    bar = bar + "*"
print(f"{name}: {bar}")

# ===== Problem 13 =====
count = 0
total = 0
number = int(input("Enter a number (0 to stop): "))
while number != 0:
    count = count + 1
    total = total + number
    number = int(input("Enter a number (0 to stop): "))
print(f"You entered {count} numbers.")
print(f"The total is {total}")

# ===== Challenge: Class Score Summary =====
PASSING_SCORE = 70
students = int(input("How many students? (1-30): "))
while students < 1 or students > 30:
    print("Please enter 1 to 30.")
    students = int(input("How many students? (1-30): "))
total = 0
passing = 0
for student in range(1, students + 1):
    score = int(input(f"Score for student {student}: "))
    while score < 0 or score > 100:
        print("Scores must be 0 to 100.")
        score = int(input(f"Score for student {student}: "))
    total = total + score
    if score >= PASSING_SCORE:
        passing = passing + 1
average = total / students
chart = ""
for count in range(passing):
    chart = chart + "#"
print()
print("--- Class Summary ---")
print(f"Students:  {students}")
print(f"Average:   {average:.1f}")
print(f"Passing:   {passing}")
if passing == 0:
    chart = "none"
print(f"Chart:     {chart}")

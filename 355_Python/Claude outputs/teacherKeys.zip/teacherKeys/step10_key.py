# ===== Problem 1: Catch one bad answer =====
try:
    age = int(input("Age: "))
    print(f"In 5 years you'll be {age + 5}.")
except ValueError:
    print("That wasn't a whole number.")

# ===== Problem 2: Ask until it's a whole number =====
while True:
    try:
        laps = int(input("How many laps? "))
        break
    except ValueError:
        print("Please enter a whole number.")
print(f"Running {laps} laps.")

# ===== Problem 3: Ask until it's a price =====
while True:
    try:
        price = float(input("Price: "))
        break
    except ValueError:
        print("Please enter a number, like 4.99")
print(f"Price: ${price:.2f}")

# ===== Problem 4: A number in a range =====
while True:
    try:
        size = int(input("Team size (2-6): "))
        if size >= 2 and size <= 6:
            break
    except ValueError:
        pass
    print("Please enter a whole number from 2 to 6.")
print(f"Team size: {size}")

# ===== Problem 5: Write get_int =====
def get_int(prompt, low, high):
    """Purpose: ask until the answer is a whole number from low to high.
    Parameters: prompt (str), low (int), high (int)
    Returns: the number (int)
    """
    while True:
        try:
            number = int(input(prompt))
            if number >= low and number <= high:
                return number
        except ValueError:    # catches letters and decimals
            pass
        print(f"Please enter a whole number from {low} to {high}.")

grade = get_int("Grade (9-12): ", 9, 12)
classes = get_int("Classes (1-8): ", 1, 8)
print(f"Grade {grade}, {classes} classes")

# ===== Problem 6: No blank names =====
name = input("Team name: ").strip()
while name == "":
    print("This cannot be blank.")
    name = input("Team name: ").strip()
print(f"Welcome, {name}!")

# ===== Problem 7: Yes or no function =====
def get_yes_no(prompt):
    """Purpose: ask until the answer is y or n.
    Parameters: prompt (str) - the question
    Returns: True for y, False for n (bool)
    """
    while True:
        answer = input(prompt).strip().lower()
        if answer == "y":
            return True
        if answer == "n":
            return False
        print("Please enter y or n.")

if get_yes_no("Do you want a receipt? (y/n): "):
    print("Printing your receipt.")
else:
    print("No receipt.")

# ===== Problem 8: Divide safely =====
try:
    points = int(input("Total points: "))
    games = int(input("Games played: "))
    print(f"Points per game: {points / games:.1f}")
except ValueError:
    print("Please type whole numbers.")
except ZeroDivisionError:
    print("Games played can't be 0.")

# ===== Problem 9: Pick from a list =====
def get_int(prompt, low, high):
    """Purpose: ask until the answer is a whole number from low to high.
    Parameters: prompt (str), low (int), high (int)
    Returns: the number (int)
    """
    while True:
        try:
            number = int(input(prompt))
            if number >= low and number <= high:
                return number
        except ValueError:    # catches letters and decimals
            pass
        print(f"Please enter a whole number from {low} to {high}.")

prizes = ["Sticker", "Water bottle", "T-shirt", "Hoodie"]
for i in range(len(prizes)):
    print(f"{i + 1}. {prizes[i]}")
choice = get_int("Pick a prize (1-4): ", 1, 4)
print(f"You picked: {prizes[choice - 1]}")

# ===== Problem 10: Skip bad lines in a file =====
total = 0
bad = 0
with open("readings.txt", "r") as data_file:
    for line in data_file:
        try:
            total = total + int(line.strip())
        except ValueError:     # catches lines that aren't whole numbers
            bad = bad + 1
print(f"Total of good lines: {total}")
print(f"Bad lines skipped: {bad}")

# ===== Problem 11: Open the file the user names =====
file_name = input("File name: ").strip()
try:
    with open(file_name, "r") as data_file:
        for line in data_file:
            print(line.strip())
except FileNotFoundError:
    print(f"Could not find {file_name}.")

# ===== Challenge: Field Trip Signup =====
BUS_COST = 350.00
TICKET_PRICE = 12.50
FILE_NAME = "signup.txt"

def get_text(prompt):
    """Purpose: ask until the answer isn't blank.
    Parameters: prompt (str)
    Returns: the answer, trimmed (str)
    """
    answer = input(prompt).strip()
    while answer == "":
        print("This cannot be blank.")
        answer = input(prompt).strip()
    return answer

def get_int(prompt, low, high):
    """Purpose: ask until the answer is a whole number from low to high.
    Parameters: prompt (str), low (int), high (int)
    Returns: the number (int)
    """
    while True:
        try:
            number = int(input(prompt))
            if number >= low and number <= high:
                return number
        except ValueError:    # catches letters and decimals
            pass
        print(f"Please enter a whole number from {low} to {high}.")

def get_yes_no(prompt):
    """Purpose: ask until the answer is y or n.
    Parameters: prompt (str)
    Returns: True for y, False for n (bool)
    """
    while True:
        answer = input(prompt).strip().lower()
        if answer == "y":
            return True
        if answer == "n":
            return False
        print("Please enter y or n.")

def main():
    """Purpose: run the program. Parameters: none. Returns: nothing"""
    teacher = get_text("Teacher name: ")
    students = get_int("Number of students (1-40): ", 1, 40)
    bus = get_yes_no("Need a bus? (y/n): ")

    total = students * TICKET_PRICE
    if bus:
        total = total + BUS_COST
    per_student = total / students

    print()
    print(f"Teacher:      {teacher}")
    print(f"Students:     {students}")
    print(f"Bus:          {'yes' if bus else 'no'}")
    print(f"Total cost:   ${total:.2f}")
    print(f"Per student:  ${per_student:.2f}")

    try:
        with open(FILE_NAME, "w") as out_file:
            print(f"{teacher},{students},{total:.2f}", file=out_file)
        print(f"Saved to {FILE_NAME}")
    except OSError:    # catches a file that can't be written
        print(f"Error: could not save {FILE_NAME}")

if __name__ == "__main__":
    main()


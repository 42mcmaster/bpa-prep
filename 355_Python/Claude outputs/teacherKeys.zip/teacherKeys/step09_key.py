# ===== Problem 1: Print a file =====
with open("team.txt", "r") as data_file:
    for line in data_file:
        print(line.strip())

# ===== Problem 2: Count the lines =====
count = 0
with open("team.txt", "r") as data_file:
    for line in data_file:
        count = count + 1
print(f"team.txt has {count} names.")

# ===== Problem 3: Numbered roster =====
number = 1
with open("team.txt", "r") as data_file:
    for line in data_file:
        print(f"{number}. {line.strip()}")
        number = number + 1

# ===== Problem 4: Read a CSV file =====
with open("prices.csv", "r") as data_file:
    data_file.readline()
    for line in data_file:
        parts = line.strip().split(",")
        price = float(parts[1])
        print(f"{parts[0]}: ${price:.2f}")

# ===== Problem 5: Total from a file =====
total = 0
count = 0
with open("prices.csv", "r") as data_file:
    data_file.readline()
    for line in data_file:
        parts = line.strip().split(",")
        total = total + float(parts[1])
        count = count + 1
print(f"{count} items cost ${total:.2f}")

# ===== Problem 6: Hottest day =====
days = []
highs = []
with open("temps.csv", "r") as data_file:
    data_file.readline()
    for line in data_file:
        parts = line.strip().split(",")
        days.append(parts[0])
        highs.append(int(parts[1]))
hottest = 0
for i in range(len(highs)):
    if highs[i] > highs[hottest]:
        hottest = i
print(f"Hottest day: {days[hottest]} ({highs[hottest]} degrees)")

# ===== Problem 7: Write a file =====
with open("goals.txt", "w") as out_file:
    print("Finish the Step 9 practice", file=out_file)
    print("Pass the IC3 exam", file=out_file)
    print("Place at BPA regionals", file=out_file)

with open("goals.txt", "r") as check_file:
    for line in check_file:
        print(line.strip())

# ===== Problem 8: Save names from input =====
with open("roster.txt", "w") as out_file:
    for count in range(3):
        name = input("Name: ")
        print(name, file=out_file)
print("Saved 3 names to roster.txt")

# ===== Problem 9: Add to a file =====
with open("practice_log.txt", "w") as log:
    print("Day 1: 20 minutes", file=log)

with open("practice_log.txt", "a") as log:
    print("Day 2: 35 minutes", file=log)

with open("practice_log.txt", "r") as log:
    for line in log:
        print(line.strip())

# ===== Problem 10: Missing file =====
try:
    with open("scores_2025.csv", "r") as data_file:
        for line in data_file:
            print(line.strip())
except FileNotFoundError:
    print("Error: scores_2025.csv was not found.")

# ===== Problem 11: Read lines with a function =====
def read_names(file_name):
    """Purpose: read a file into a list of lines.
    Parameters: file_name (str) - the file to read
    Returns: the lines, stripped (list of str)
    """
    names = []
    with open(file_name, "r") as data_file:
        for line in data_file:
            names.append(line.strip())
    return names

team = read_names("team.txt")
print(team)
print(f"{len(team)} names")

# ===== Challenge: Quiz Report From a File =====
FILE_NAME = "quiz_scores.csv"
REPORT_NAME = "quiz_report.txt"
PASSING = 70

def read_scores(file_name):
    """Purpose: read names and scores from a CSV file.
    Parameters: file_name (str)
    Returns: a list of names and a list of scores
    """
    names = []
    scores = []
    with open(file_name, "r") as data_file:
        data_file.readline()
        for line in data_file:
            parts = line.strip().split(",")
            names.append(parts[0])
            scores.append(int(parts[1]))
    return names, scores

def print_report(names, scores, out_file=None):
    """Purpose: print the report to the screen or a file.
    Parameters: names (list), scores (list), out_file - a file, or None for the screen
    Returns: nothing
    """
    total = 0
    best = 0
    for i in range(len(names)):
        if scores[i] >= PASSING:
            result = "PASS"
        else:
            result = "FAIL"
        print(f"{names[i]:<8}{scores[i]:>4}  {result}", file=out_file)
        total = total + scores[i]
        if scores[i] > scores[best]:
            best = i
    print(f"Average: {total / len(scores):.1f}", file=out_file)
    print(f"Highest: {names[best]} ({scores[best]})", file=out_file)

def main():
    """Purpose: run the program. Parameters: none. Returns: nothing"""
    try:
        names, scores = read_scores(FILE_NAME)
    except FileNotFoundError:
        print(f"Error: {FILE_NAME} was not found.")
        return
    print(f"Read {len(names)} scores from {FILE_NAME}")
    print()
    print_report(names, scores)
    with open(REPORT_NAME, "w") as report:
        print_report(names, scores, report)
    print()
    print(f"Report saved to {REPORT_NAME}")

if __name__ == "__main__":
    main()


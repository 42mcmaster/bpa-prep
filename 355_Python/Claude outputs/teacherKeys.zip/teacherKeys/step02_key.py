# ===== Problem 1: Store and print =====
team = "Code Crushers"
wins = 7
losses = 2
print(f"Team:   {team}")
print(f"Wins:   {wins}")
print(f"Losses: {losses}")

# ===== Problem 2: Say hello =====
name = input("Your name: ")
subject = input("Favorite class: ")
print(f"Hi {name}! {subject} is a great class.")

# ===== Problem 3: Ten years from now =====
age = int(input("Age: "))
print(f"In 10 years you will be {age + 10}.")

# ===== Problem 4: Add two numbers =====
first = int(input("First number: "))
second = int(input("Second number: "))
print(f"Sum:     {first + second}")
print(f"Product: {first * second}")

# ===== Problem 5: Room area =====
length = float(input("Length (feet): "))
width = float(input("Width (feet): "))
area = length * width
print(f"Area: {area:.1f} square feet")

# ===== Problem 6: Hours and minutes =====
minutes = int(input("Total minutes: "))
hours = minutes // 60
left_over = minutes % 60
print(f"{minutes} minutes is {hours} hr {left_over} min")

# ===== Problem 7: Price with tax =====
TAX_RATE = 0.0675

price = float(input("Price: "))
tax = price * TAX_RATE
total = price + tax
print(f"Tax:   ${tax:.2f}")
print(f"Total: ${total:.2f}")

# ===== Problem 8: Split the bill =====
bill = float(input("Bill total: "))
people = int(input("Number of people: "))
share = bill / people
print(f"Each person pays ${share:.2f}")

# ===== Problem 9: Average of three =====
score1 = int(input("Score 1: "))
score2 = int(input("Score 2: "))
score3 = int(input("Score 3: "))
average = (score1 + score2 + score3) / 3
print(f"Average: {average:.1f}")

# ===== Problem 10: Fahrenheit to Celsius =====
fahrenheit = float(input("Temperature (F): "))
celsius = (fahrenheit - 32) * 5 / 9
print(f"{fahrenheit:.1f} F is {celsius:.1f} C")

# ===== Problem 11: Cookie boxes =====
COOKIES_PER_BOX = 12

cookies = int(input("Cookies baked: "))
boxes = cookies // COOKIES_PER_BOX
extra = cookies % COOKIES_PER_BOX
print(f"Full boxes:  {boxes}")
print(f"Left over:   {extra}")

# ===== Problem 12: A receipt =====
item = input("Item: ")
quantity = int(input("Quantity: "))
price = float(input("Price each: "))
total = quantity * price
print()
print("=" * 24)
print(f"Item:      {item}")
print(f"Quantity:  {quantity}")
print(f"Price:     ${price:.2f}")
print(f"Total:     ${total:.2f}")
print("=" * 24)

# ===== Challenge: Movie Night Snacks =====
# Constants
POPCORN_PRICE = 4.50
DRINK_PRICE = 2.75
TAX_RATE = 0.0675

# Input
name = input("Name: ")
popcorn = int(input("Popcorn: "))
drinks = int(input("Drinks: "))

# Processing
popcorn_cost = popcorn * POPCORN_PRICE
drink_cost = drinks * DRINK_PRICE
subtotal = popcorn_cost + drink_cost
tax = subtotal * TAX_RATE
total = subtotal + tax

# Output
print()
print("=" * 28)
print(f"Snack order for {name}")
print("=" * 28)
print(f"Popcorn x {popcorn}:    ${popcorn_cost:.2f}")
print(f"Drinks x {drinks}:     ${drink_cost:.2f}")
print("-" * 28)
print(f"Subtotal:       ${subtotal:.2f}")
print(f"Tax:            ${tax:.2f}")
print(f"Total:          ${total:.2f}")

